from __future__ import annotations

import json
import os
import random
from dataclasses import asdict, dataclass
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory


BASE_DIR = Path(__file__).resolve().parent
HTML_FILE = "side-quest-irl.html"

app = Flask(__name__, static_folder=str(BASE_DIR), static_url_path="")


@dataclass
class Quest:
    id: int
    title: str
    category: str
    rarity: str
    xp: int
    time: str
    detail: str
    icon: str


quests: list[Quest] = [
    Quest(1, "Taste the Unknown", "Food", "Common", 120, "20 min", "Try a food you have never eaten and rate it like a field discovery.", "ramen"),
    Quest(2, "RGB Photo Hunt", "Photo", "Rare", 180, "15 min", "Find red, blue, and green in one place. Capture proof for the feed.", "camera"),
    Quest(3, "Three Words: Japanese", "Learn", "Epic", 260, "25 min", "Learn three Japanese words and record yourself using one sentence.", "language"),
    Quest(4, "Brave Hello", "Social", "Common", 140, "10 min", "Talk to someone new, ask one kind question, and log the answer.", "spark"),
]

generated_templates = [
    ("Neighborhood Soundtrack", "Photo", "Rare", 190, "Record or describe three sounds from a short walk.", "music"),
    ("Tiny Kindness", "Social", "Epic", 280, "Do one helpful thing for someone and log what changed.", "heart"),
    ("Snack Passport", "Food", "Rare", 220, "Find a snack from a country you have never visited.", "passport"),
    ("One-Minute Mastery", "Learn", "Common", 130, "Learn one tiny skill and explain it in a short clip.", "bolt"),
]

quest_schema = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "title": {"type": "string", "maxLength": 56},
        "category": {"type": "string", "enum": ["Food", "Photo", "Learn", "Social"]},
        "rarity": {"type": "string", "enum": ["Common", "Rare", "Epic", "Legend"]},
        "xp": {"type": "integer", "minimum": 50, "maximum": 500},
        "time": {"type": "string", "maxLength": 18},
        "detail": {"type": "string", "maxLength": 150},
        "icon": {"type": "string", "enum": ["ramen", "camera", "language", "spark", "music", "heart", "passport", "bolt"]},
    },
    "required": ["title", "category", "rarity", "xp", "time", "detail", "icon"],
}

player = {
    "level": 12,
    "xp": 3240,
    "nextLevelXp": 5000,
    "streakDays": 9,
    "completedQuests": 47,
    "badges": ["Food Finder", "Color Hunter", "Word Wizard", "Brave Hello"],
}


def fallback_generated_quest() -> Quest:
    title, category, rarity, xp, detail, icon = random.choice(generated_templates)
    return Quest(
        id=max((item.id for item in quests), default=0) + 1,
        title=title,
        category=category,
        rarity=rarity,
        xp=xp,
        time="15 min",
        detail=detail,
        icon=icon,
    )


def chatgpt_generated_quest(interests: str = "") -> Quest | None:
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return None

    try:
        from openai import OpenAI
    except ImportError:
        return None

    model = os.environ.get("OPENAI_MODEL", "gpt-5.5")
    client = OpenAI(api_key=api_key)
    interest_text = interests.strip() or "food, photography, languages, meeting new people, outdoor exploration"

    response = client.responses.create(
        model=model,
        instructions=(
            "You generate safe, teen-friendly real-world side quests for an app called Side Quest IRL. "
            "The style should feel like a bright location-based RPG and a social short-video challenge feed. "
            "Do not mention Pokemon, Instagram, or any protected brand names. "
            "Keep quests low-cost, legal, public-space friendly, and doable without risky dares."
        ),
        input=(
            "Create one fresh side quest. "
            f"Player interests: {interest_text}. "
            "Make it specific, fun, and easy to capture as a short proof reel."
        ),
        text={
            "format": {
                "type": "json_schema",
                "name": "side_quest",
                "strict": True,
                "schema": quest_schema,
            }
        },
    )

    data = json.loads(response.output_text)
    return Quest(
        id=max((item.id for item in quests), default=0) + 1,
        title=data["title"],
        category=data["category"],
        rarity=data["rarity"],
        xp=int(data["xp"]),
        time=data["time"],
        detail=data["detail"],
        icon=data["icon"],
    )


@app.get("/")
def home():
    return send_from_directory(BASE_DIR, HTML_FILE)


@app.get("/api/quests")
def list_quests():
    category = request.args.get("category", "All")
    search = request.args.get("search", "").strip().lower()

    filtered = quests
    if category != "All":
        filtered = [quest for quest in filtered if quest.category == category]
    if search:
        filtered = [
            quest
            for quest in filtered
            if search in f"{quest.title} {quest.category} {quest.rarity} {quest.detail}".lower()
        ]

    return jsonify([asdict(quest) for quest in filtered])


@app.post("/api/quests/generate")
def generate_quest():
    data = request.get_json(silent=True) or {}
    interests = str(data.get("interests", ""))

    try:
        quest = chatgpt_generated_quest(interests)
        if quest is None:
            quest = fallback_generated_quest()
            source = "fallback"
        else:
            source = "chatgpt"
    except Exception as error:
        quest = fallback_generated_quest()
        source = f"fallback: {error.__class__.__name__}"

    quests.insert(0, quest)
    return jsonify({"quest": asdict(quest), "source": source}), 201


@app.post("/api/quests")
def create_quest():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    category = str(data.get("category", "Photo")).strip()
    xp = int(data.get("xp", 175))

    if not title:
        return jsonify({"error": "Quest title is required."}), 400

    quest = Quest(
        id=max((item.id for item in quests), default=0) + 1,
        title=title[:56],
        category=category,
        rarity="Rare",
        xp=max(50, min(xp, 1000)),
        time="Custom",
        detail="A custom challenge created by your squad.",
        icon="custom",
    )
    quests.insert(0, quest)
    return jsonify(asdict(quest)), 201


@app.post("/api/quests/<int:quest_id>/complete")
def complete_quest(quest_id: int):
    quest = next((item for item in quests if item.id == quest_id), None)
    if quest is None:
        return jsonify({"error": "Quest not found."}), 404

    player["xp"] += quest.xp
    player["completedQuests"] += 1

    leveled_up = False
    if player["xp"] >= player["nextLevelXp"]:
        player["xp"] -= player["nextLevelXp"]
        player["level"] += 1
        leveled_up = True

    return jsonify({"player": player, "completedQuest": asdict(quest), "leveledUp": leveled_up})


@app.get("/api/player")
def get_player():
    return jsonify(player)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=4173, debug=True)
